const {Schema, model} = require("mongoose");

const subjectSchema = new Schema({
    subjectname: {type: String, required: true},
});
const Subject = new model('Subject',subjectSchema);
module.exports = Subject;