const Classmaster = require("../models/classmaster-model");

function formatDate(dateString) {
    const date = new Date(dateString);
    const day = ('0' + date.getDate()).slice(-2);
    const month = ('0' + (date.getMonth() + 1)).slice(-2); // Months are zero-based
    const year = date.getFullYear();

    return `${day}/${month}/${year}`;
}

const add = async (req,res)=>{
    try {
        console.log(req.body);
        const { classname , endate} = req.body;
        const formattedDate = formatDate(endate);
        const status =1;
        const userExist = await Classmaster.findOne({ classname });
        
        if(userExist){
            return res.status(400).json({message:"Class already exist"});
        }

        const cmCreated =  await Classmaster.create( { classname , endate:formattedDate , status} );
        res.status(201).json({
            message:'Class added Successfully',
            userId:cmCreated._id.toString(),
        });

    } catch (error) {
      res.status(500).json(error);
    }
};

const update = async (req,res)=>{
    try {
        console.log(req.body);
        const {  classname , endate} = req.body;
        const id = req.params.id;
 
        const userExist = await Classmaster.findOne({ classname, _id: { $ne: id }});
        
        if(userExist){
            return res.status(400).json({msg:"ClassName already exist"});

        }
        const result = await Classmaster.updateOne({ _id:id },{
            $set:{
                classname: classname,
                endate:endate,
            }
        },{
            new:true,
        });
        res.status(201).json({
            msg:'Updated Successfully',
        });

    } catch (error) {
     res.status(500).json(error);
    }
};

const  get = async(req, res) => {
    try {
        const response = await Classmaster.find();
        if(!response){
            res.status(404).json({msg:"No Data Found"});
            return;
        }
        res.status(200).json({msg:response});
    } catch (error) {
        console.log(`ClassMaster ${error}`);
    }
};

const  deletecm = async(req, res) => {
    try {

        const id = req.params.id;
        const response = await Classmaster.findOneAndDelete(({_id:id}));
        if(!response){
            res.status(404).json({msg:"No Data Found"});
            return;
        }
        res.status(200).json({msg:response});
    } catch (error) {
        console.log(`ClassMaster ${error}`);
    }
};
module.exports = { add , update , get, deletecm};