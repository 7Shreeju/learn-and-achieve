import logo from "../assets/images/logo.png";
import logoDark from "../assets/images/logo-dark.svg";

// Authentication
import login from "../assets/images/auth/login.png";

// Dashboard
import user from "../assets/images/user.png";

//Add Study Material
import Notfound from "./../assets/images/modulenotfound.png";

import welldone from "./../assets/images/well-done.png";
import noModule from "../assets/images/no-module.svg";

export { logo, logoDark, login, user, Notfound, welldone, noModule };
