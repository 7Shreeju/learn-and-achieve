import React, { useState, useEffect } from "react";
import DataTable from "react-data-table-component";
import {
    Delete,
    Edit,
    ButtonPlus,
    ArrowLeft,
    ButtonArrowRight,
    UploadFile,
    Calender,
  } from "../components/SvgIcons";

const Classmastertable = () => {
    
    const [search, setSearch] = useState("");
    const [filters, setFilter] = useState([]);
    const [classmaster, setClassmaster] = useState([]);

    const handleDelete =(par) => {
        console.log(par);
    }

    const getdata= async () => {
        try {
        const response = await fetch("http://localhost:5000/api/classmaster/get",{
            method:"GET",
        });
        // console.log();
        const data = await response.json();
        setClassmaster(data.msg);
        setFilter(data.msg);
        } catch (error) {
           console.log(error);
        }
    };

    
    const columns= [
      {
        name:<div className='form-check'> <input className='form-check-input' type='checkbox' value='' /> </div>,
        selector: (row, index) => <div className="form-check"> <input className="form-check-input" type="checkbox" value="" /> </div>,
        sortable: false  
    },
      {
        name:"Sr No.",
        selector: (row, index) => index + 1,
        sortable: true  
      },
      {
        name:"Class",
        selector: (row) => row.classname,
        sortable: true  
      },
      {
        name:"Class End Date",
        selector: (row) => row.endate,
        sortable: true  
      },
      {
        name:"Status",
        selector: (row) => row.status =='1'?<span class="toggle" href="#change-popup" data-bs-toggle="modal"><input type="checkbox" checked id="toggle-switch" /><label for="toggle-switch"></label></span>:<span class="toggle" href="#change-popup" data-bs-toggle="modal"><input type="checkbox" unchecked id="toggle-switch" /><label for="toggle-switch"></label></span>,
      },
      {
        name:"Action",
        selector: (row) => <div className="svg-de-icon"><button className="edit" href="#edit-class-popup" data-bs-toggle="modal"><Edit /></button><button onClick={() => handleDelete(row._id)} className="delete"  href="#delete-popup" data-bs-toggle="modal"><Delete /></button></div>
      },
    ]

    useEffect(()=>{
        getdata();
    }, []);

    useEffect(()=>{    
        const result= classmaster.filter(classmas =>{
            return classmas.classname.toLowerCase().match(search.toLowerCase());
            return classmas.endate.toLowerCase().match(search.toLowerCase());
        });
        setFilter(result);    
    }, [search]);


    return <DataTable 
            className="data-tables" 
            columns={columns} 
            data={filters} 
            pagination
            fixedHeader
            fixedHeaderScrollHeight="450px"
            highlightOnHover
            subHeader
            subHeaderComponent={<input type="text" value={search} onChange={(e)=> setSearch(e.target.value)} placeholder="Search here" className="w-25 form-control"/>}
            />;
};

export default Classmastertable